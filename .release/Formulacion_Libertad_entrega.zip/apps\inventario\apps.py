from django.apps import AppConfig


class InventarioConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.inventario"
    label = "inventario"
    verbose_name = "Inventario"

    def ready(self):
        from . import signals  # noqa: F401
